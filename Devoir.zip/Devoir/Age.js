const http = require('node:http');

const serveur = http.createServer((req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  if (req.method === 'GET') {
    const valeurUrl = req.url.slice(1);
    const age = Number(valeurUrl);

    if (valeurUrl !== '' && !isNaN(age) && age >= 0) {
      res.writeHead(200);

      if (age < 18) {
        return res.end(JSON.stringify({ vousêtes: `mineur : ${age} ans` }));
      }

      if (age >= 18) {
        return res.end(JSON.stringify({ vousêtes: `majeur : ${age} ans` }));
      }
    }
  }

  res.writeHead(404);
  return res.end(JSON.stringify({ message:'Page introuvable'}));
});

serveur.listen(3002, () => console.log('http://localhost:3002'));
