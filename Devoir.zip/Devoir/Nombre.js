const http = require('node:http');

const serveur = http.createServer((req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  if (req.method === 'GET') {
    const valeurUrl = req.url.slice(1);
    const nombre = Number(valeurUrl);

    if (valeurUrl !== '' && !isNaN(nombre) && nombre >= 0) {
      res.writeHead(200);

      if (nombre % 2 === 0) {
        return res.end(JSON.stringify({ message: `paire : ${nombre} ` }));
      }
      if (nombre % 2 !== 0) {
        return res.end(JSON.stringify({ message: `impaire : ${nombre} ` }));
      }
    }
  }

   res.writeHead(404);
  return res.end(JSON.stringify({ message:'Page introuvable'}));
});

serveur.listen(3003, () => console.log('http://localhost:3003'));

